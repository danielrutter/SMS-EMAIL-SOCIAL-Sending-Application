// File Location: /js/send_a_free_text_message.js

function ResetFormData() {
    document.getElementById("send_a_free_text_message").reset();
}
